import { parseRss } from './rss.js';
import { parseReddit } from './reddit.js';

export async function runParser(source) {
  switch (source.type) {
    case 'rss':
    case 'scraper':
      return parseRss(source);
    case 'reddit':
      return parseReddit(source);
    case 'nitter':
      throw new Error('Nitter parser not implemented yet');
    default:
      throw new Error(`Unknown source type: ${source.type}`);
  }
}
